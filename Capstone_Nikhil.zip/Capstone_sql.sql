show tables;
select * from employees;
select * from offices;
select * from orderdetails;
select * from orders;
select * from payments;
select * from productlines;
select * from products;
-- office O, customer C, order O, order details OD, products P.


SELECT customers.customerNumber,orders.orderdate,
customers.customerName,customers.country, orderdetails.productCode,
orderdetails.quantityOrdered,orderdetails.priceEach
FROM orders
JOIN customers ON orders.customerNumber = customers.customerNumber
JOIN orderdetails ON orders.orderNumber= orderdetails.orderNumber;

